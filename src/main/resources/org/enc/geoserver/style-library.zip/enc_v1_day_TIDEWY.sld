<?xml version='1.0' encoding='utf-8'?>
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" version="1.0.0">
  <NamedLayer>
    <Name>enc_v1_day_TIDEWY</Name>
    <UserStyle>
      <Title>enc_v1_day_TIDEWY</Title>
      <FeatureTypeStyle>
        <Rule>
          <Name>TIDEWY-31918</Name>
          <ogc:Filter>
            <ogc:And>
              <ogc:And>
                <ogc:PropertyIsEqualTo>
                  <ogc:PropertyName>_enc_lookup</ogc:PropertyName>
                  <ogc:Literal>31918</ogc:Literal>
                </ogc:PropertyIsEqualTo>
                <ogc:Or>
                  <ogc:PropertyIsEqualTo>
                    <ogc:PropertyName>_enc_safety</ogc:PropertyName>
                    <ogc:Literal>1</ogc:Literal>
                  </ogc:PropertyIsEqualTo>
                  <ogc:Or>
                    <ogc:PropertyIsNull>
                      <ogc:PropertyName>SCAMIN</ogc:PropertyName>
                    </ogc:PropertyIsNull>
                    <ogc:PropertyIsEqualTo>
                      <ogc:PropertyName>SCAMIN</ogc:PropertyName>
                      <ogc:Literal>0</ogc:Literal>
                    </ogc:PropertyIsEqualTo>
                    <ogc:PropertyIsLessThanOrEqualTo>
                      <ogc:Function name="env">
                        <ogc:Literal>enc_scale_denominator</ogc:Literal>
                        <ogc:Function name="env">
                          <ogc:Literal>wms_scale_denominator</ogc:Literal>
                          <ogc:Literal>1</ogc:Literal>
                        </ogc:Function>
                      </ogc:Function>
                      <ogc:PropertyName>SCAMIN</ogc:PropertyName>
                    </ogc:PropertyIsLessThanOrEqualTo>
                  </ogc:Or>
                </ogc:Or>
              </ogc:And>
              <ogc:PropertyIsEqualTo>
                <ogc:PropertyName>_enc_priority</ogc:PropertyName>
                <ogc:Literal>3</ogc:Literal>
              </ogc:PropertyIsEqualTo>
            </ogc:And>
          </ogc:Filter>
          <LineSymbolizer>
            <Geometry>
              <ogc:PropertyName>_enc_line</ogc:PropertyName>
            </Geometry>
            <Stroke>
              <CssParameter name="stroke">#a3b4b7</CssParameter>
              <CssParameter name="stroke-width">0.6</CssParameter>
            </Stroke>
          </LineSymbolizer>
        </Rule>
        <Rule>
          <Name>TIDEWY-32231</Name>
          <ogc:Filter>
            <ogc:And>
              <ogc:And>
                <ogc:PropertyIsEqualTo>
                  <ogc:PropertyName>_enc_lookup</ogc:PropertyName>
                  <ogc:Literal>32231</ogc:Literal>
                </ogc:PropertyIsEqualTo>
                <ogc:Or>
                  <ogc:PropertyIsEqualTo>
                    <ogc:PropertyName>_enc_safety</ogc:PropertyName>
                    <ogc:Literal>1</ogc:Literal>
                  </ogc:PropertyIsEqualTo>
                  <ogc:Or>
                    <ogc:PropertyIsNull>
                      <ogc:PropertyName>SCAMIN</ogc:PropertyName>
                    </ogc:PropertyIsNull>
                    <ogc:PropertyIsEqualTo>
                      <ogc:PropertyName>SCAMIN</ogc:PropertyName>
                      <ogc:Literal>0</ogc:Literal>
                    </ogc:PropertyIsEqualTo>
                    <ogc:PropertyIsLessThanOrEqualTo>
                      <ogc:Function name="env">
                        <ogc:Literal>enc_scale_denominator</ogc:Literal>
                        <ogc:Function name="env">
                          <ogc:Literal>wms_scale_denominator</ogc:Literal>
                          <ogc:Literal>1</ogc:Literal>
                        </ogc:Function>
                      </ogc:Function>
                      <ogc:PropertyName>SCAMIN</ogc:PropertyName>
                    </ogc:PropertyIsLessThanOrEqualTo>
                  </ogc:Or>
                </ogc:Or>
              </ogc:And>
              <ogc:PropertyIsEqualTo>
                <ogc:PropertyName>_enc_priority</ogc:PropertyName>
                <ogc:Literal>7</ogc:Literal>
              </ogc:PropertyIsEqualTo>
            </ogc:And>
          </ogc:Filter>
          <TextSymbolizer>
            <Label>
              <ogc:PropertyName>OBJNAM</ogc:PropertyName>
            </Label>
            <Font>
              <CssParameter name="font-family">DejaVu Sans</CssParameter>
              <CssParameter name="font-size">16.0</CssParameter>
              <CssParameter name="font-weight">normal</CssParameter>
            </Font>
            <LabelPlacement>
              <PointPlacement>
                <AnchorPoint>
                  <AnchorPointX>0.5</AnchorPointX>
                  <AnchorPointY>0.5</AnchorPointY>
                </AnchorPoint>
                <Displacement>
                  <DisplacementX>0.0</DisplacementX>
                  <DisplacementY>-0.0</DisplacementY>
                </Displacement>
              </PointPlacement>
            </LabelPlacement>
            <Fill>
              <CssParameter name="fill">#070707</CssParameter>
            </Fill>
            <VendorOption name="conflictResolution">true</VendorOption>
            <VendorOption name="spaceAround">2</VendorOption>
          </TextSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>